# DAGRON DevOps

## Vision retenue

`DAGRON DevOps` est conçu comme un éditeur `desktop-first` inspiré de l’expérience d’un IDE moderne, avec une architecture qui pourra ensuite être portée vers un mode web local. Le socle actuel privilégie les fonctions réellement exécutables en local : authentification, navigation dans le système de fichiers, édition, sauvegarde, terminal intégré, lecture d’état Git et détection d’un runtime IA local.

## Architecture du socle

### Interface

- `React` pour l’interface
- `Monaco Editor` pour l’édition de code
- thème sombre et panneaux latéraux proches d’un IDE moderne

### Hôte desktop

- `Electron` comme conteneur d’application
- `preload` sécurisé pour exposer des API locales contrôlées
- `IPC` pour connecter l’interface aux services système
- session terminal locale pilotée par le backend

### Services locaux

- accès fichiers via `fs/promises`
- exécution de commandes via `child_process`
- détection Git via commandes locales
- stockage des préférences et du mot de passe haché dans l’espace applicatif local

### IA locale

- détection d’`Ollama` en priorité
- architecture de catalogue pour extensions et agents locaux
- point d’extension prévu pour plusieurs moteurs plus tard

## Modules inclus dans ce premier socle

- écran de verrouillage avec mot de passe local
- explorateur de dossier courant
- ouverture et sauvegarde de fichiers texte
- éditeur `Monaco`
- terminal intégré avec historique de session
- panneau `Amélioré` avec activation ou désactivation de modules
- panneau droit de contexte
- barre d’état
- runner de commandes locales
- remontée de l’état Git
- détection des modèles `Ollama`

## MVP conseillé

### Lot 1

- shell desktop stable
- authentification locale
- explorateur, onglets simples, sauvegarde
- barre d’état
- terminal intégré et runner de commandes

### Lot 2

- arborescence récursive
- recherche globale projet
- palette de commandes
- historique des fichiers récents
- panneau Git enrichi

### Lot 3

- chat IA local contextualisé
- sélection de modèle par usage
- actions sur sélection de code
- génération de tests et documentation
- revue défensive de code

### Lot 4

- système d’extensions local versionné
- catalogue configurable
- web local basé sur le même noyau de services

## Décisions importantes

- le mode `desktop` passe en premier pour conserver l’accès natif au système, au terminal et à Git
- le mode web local viendra ensuite via une couche de services réutilisable
- les fonctions offensives ne font pas partie du produit
- les intégrations IA distantes restent facultatives et désactivées par défaut

## Prochaine étape recommandée

Le meilleur enchaînement est :

1. stabiliser le shell et l’explorateur
2. ajouter le chat IA local et le contexte de code
3. brancher un moteur d’extensions local
4. étendre la recherche projet et Git
