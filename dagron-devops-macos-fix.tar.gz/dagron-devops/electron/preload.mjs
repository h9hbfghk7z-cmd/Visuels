import { contextBridge, ipcRenderer } from 'electron'

contextBridge.exposeInMainWorld('dagronApi', {
  getShellData: () => ipcRenderer.invoke('app:get-shell-data'),
  authStatus: () => ipcRenderer.invoke('auth:status'),
  setupPassword: (password) => ipcRenderer.invoke('auth:setup', password),
  unlock: (password) => ipcRenderer.invoke('auth:unlock', password),
  listWorkspace: (relativePath) => ipcRenderer.invoke('workspace:list', relativePath),
  readFile: (relativePath) => ipcRenderer.invoke('workspace:readFile', relativePath),
  saveFile: (relativePath, content) =>
    ipcRenderer.invoke('workspace:saveFile', relativePath, content),
  runCommand: (command) => ipcRenderer.invoke('workspace:runCommand', command),
  gitStatus: () => ipcRenderer.invoke('workspace:gitStatus'),
  getAgents: () => ipcRenderer.invoke('workspace:agents'),
  getCatalog: () => ipcRenderer.invoke('workspace:catalog'),
  toggleExtension: (extensionId) =>
    ipcRenderer.invoke('workspace:toggleExtension', extensionId),
  getLanguage: (relativePath) => ipcRenderer.invoke('workspace:getLanguage', relativePath),
  ensureTerminal: () => ipcRenderer.invoke('terminal:ensure'),
  runTerminalCommand: (command) => ipcRenderer.invoke('terminal:run', command),
  interruptTerminal: () => ipcRenderer.invoke('terminal:interrupt'),
  clearTerminal: () => ipcRenderer.invoke('terminal:clear'),
  restartTerminal: () => ipcRenderer.invoke('terminal:restart'),
  onTerminalData: (callback) => {
    const listener = (_event, payload) => callback(payload)
    ipcRenderer.on('terminal:data', listener)
    return () => ipcRenderer.removeListener('terminal:data', listener)
  },
  onTerminalState: (callback) => {
    const listener = (_event, payload) => callback(payload)
    ipcRenderer.on('terminal:state', listener)
    return () => ipcRenderer.removeListener('terminal:state', listener)
  },
})
