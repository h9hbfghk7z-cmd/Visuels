import { app, BrowserWindow, ipcMain } from 'electron'
import { createHash } from 'node:crypto'
import { exec, execFile, spawn } from 'node:child_process'
import { promisify } from 'node:util'
import fs from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const execAsync = promisify(exec)
const execFileAsync = promisify(execFile)
const __dirname = path.dirname(fileURLToPath(import.meta.url))
const isDev = !app.isPackaged
const DEV_SERVER_URL = process.env.DAGRON_DEV_URL || 'http://localhost:5173'
const DEFAULT_PASSWORD = 'dagron'
const DEFAULT_CATALOG = [
  {
    id: 'ollama-runtime',
    name: 'Ollama',
    category: 'Agent IA local',
    description: 'Runtime local pour exécuter des modèles open source.',
  },
  {
    id: 'git-tools',
    name: 'Git local',
    category: 'Développement',
    description: 'Intégration des branches, de l’état du dépôt et de l’historique.',
  },
  {
    id: 'security-audit',
    name: 'Audit défensif',
    category: 'Sécurité',
    description: 'Analyse de dépendances, configuration et remédiation assistée.',
  },
]

let mainWindow = null
let terminalSession = null

function sha256(value) {
  return createHash('sha256').update(value).digest('hex')
}

async function pathExists(targetPath) {
  try {
    await fs.access(targetPath)
    return true
  } catch {
    return false
  }
}

async function getWorkspaceRoot() {
  const candidates = [
    process.env.DAGRON_WORKSPACE_ROOT,
    '/workspace',
    process.cwd(),
  ].filter(Boolean)

  for (const candidate of candidates) {
    if (await pathExists(candidate)) {
      return candidate
    }
  }

  return process.cwd()
}

function getSettingsPath() {
  return path.join(app.getPath('userData'), 'dagron-settings.json')
}

async function readSettings() {
  const filePath = getSettingsPath()

  try {
    const raw = await fs.readFile(filePath, 'utf8')
    return JSON.parse(raw)
  } catch {
    const defaults = {
      passwordHash: sha256(DEFAULT_PASSWORD),
      extensions: {
        'git-tools': true,
        'security-audit': true,
      },
    }

    await fs.writeFile(filePath, JSON.stringify(defaults, null, 2), 'utf8')
    return defaults
  }
}

async function writeSettings(partialSettings) {
  const current = await readSettings()
  const next = { ...current, ...partialSettings }
  await fs.writeFile(getSettingsPath(), JSON.stringify(next, null, 2), 'utf8')
  return next
}

async function ensureInsideWorkspace(targetPath) {
  const root = await getWorkspaceRoot()
  const resolved = path.resolve(root, targetPath || '.')
  const relative = path.relative(root, resolved)

  if (relative.startsWith('..') || path.isAbsolute(relative)) {
    throw new Error('Chemin hors du dossier de travail.')
  }

  return { root, resolved }
}

async function listDirectory(relativePath = '.') {
  const { resolved, root } = await ensureInsideWorkspace(relativePath)
  const entries = await fs.readdir(resolved, { withFileTypes: true })

  return {
    root,
    currentPath: path.relative(root, resolved) || '.',
    items: entries
      .filter((entry) => !entry.name.startsWith('.'))
      .sort((left, right) => {
        if (left.isDirectory() && !right.isDirectory()) return -1
        if (!left.isDirectory() && right.isDirectory()) return 1
        return left.name.localeCompare(right.name)
      })
      .map((entry) => ({
        name: entry.name,
        path: path.relative(root, path.join(resolved, entry.name)) || '.',
        type: entry.isDirectory() ? 'directory' : 'file',
      })),
  }
}

async function readTextFile(relativePath) {
  const { resolved } = await ensureInsideWorkspace(relativePath)
  const content = await fs.readFile(resolved, 'utf8')
  return { path: relativePath, content }
}

async function saveTextFile(relativePath, content) {
  const { resolved } = await ensureInsideWorkspace(relativePath)
  await fs.writeFile(resolved, content, 'utf8')
  return { saved: true, path: relativePath }
}

async function hasCommand(command) {
  const checker = process.platform === 'win32' ? 'where' : 'which'

  try {
    await execFileAsync(checker, [command])
    return true
  } catch {
    return false
  }
}

async function getGitStatus() {
  const root = await getWorkspaceRoot()

  try {
    const [{ stdout: branch }, { stdout: status }] = await Promise.all([
      execFileAsync('git', ['rev-parse', '--abbrev-ref', 'HEAD'], { cwd: root }),
      execFileAsync('git', ['status', '--porcelain'], { cwd: root }),
    ])

    return {
      branch: branch.trim() || 'aucune',
      dirty: status.trim().length > 0,
    }
  } catch {
    return {
      branch: 'hors dépôt',
      dirty: false,
    }
  }
}

async function getLocalAgents() {
  const ollamaInstalled = await hasCommand('ollama')
  let models = []

  if (ollamaInstalled) {
    try {
      const { stdout } = await execFileAsync('ollama', ['list'])
      models = stdout
        .split('\n')
        .slice(1)
        .map((line) => line.trim().split(/\s+/)[0])
        .filter(Boolean)
    } catch {
      models = []
    }
  }

  return {
    runtime: ollamaInstalled ? 'Ollama détecté' : 'Aucun runtime IA détecté',
    models,
  }
}

async function getEnhancedCatalog() {
  const settings = await readSettings()
  const agents = await getLocalAgents()

  return DEFAULT_CATALOG.map((item) => ({
    ...item,
    active: Boolean(settings.extensions?.[item.id]),
    installed:
      item.id === 'ollama-runtime'
        ? agents.runtime === 'Ollama détecté'
        : true,
  }))
}

async function toggleExtension(extensionId) {
  const settings = await readSettings()
  const currentValue = Boolean(settings.extensions?.[extensionId])

  const next = await writeSettings({
    extensions: {
      ...settings.extensions,
      [extensionId]: !currentValue,
    },
  })

  return Boolean(next.extensions?.[extensionId])
}

async function runShellCommand(command) {
  const root = await getWorkspaceRoot()

  if (!command || !command.trim()) {
    throw new Error('Commande vide.')
  }

  const { stdout, stderr } = await execAsync(command, {
    cwd: root,
    timeout: 15000,
    maxBuffer: 1024 * 1024,
    shell: true,
  })

  return {
    stdout,
    stderr,
    cwd: root,
  }
}

function getSystemShell() {
  if (process.platform === 'win32') {
    return {
      label: 'PowerShell',
      command: 'powershell.exe',
      buildArgs: (userCommand) => ['-NoLogo', '-NoProfile', '-Command', userCommand],
    }
  }

  return {
    label: path.basename(process.env.SHELL || '/bin/bash'),
    command: process.env.SHELL || '/bin/bash',
    buildArgs: (userCommand) => ['-lc', userCommand],
  }
}

function getEmptyTerminalState() {
  return {
    running: false,
    busy: false,
    cwd: '',
    shell: getSystemShell().label,
    output: '',
    history: [],
    lastExitCode: null,
    env: {},
    activeProcess: null,
  }
}

function sendTerminalEvent(channel, payload) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send(channel, payload)
  }
}

function normalizeChunk(chunk) {
  return chunk.replace(/\r?\n/g, '\r\n')
}

function appendTerminalOutput(chunk) {
  if (!terminalSession) return

  const normalized = normalizeChunk(chunk)
  terminalSession.output = `${terminalSession.output}${normalized}`.slice(-120000)
  sendTerminalEvent('terminal:data', { chunk: normalized })
}

function getTerminalSnapshot() {
  if (!terminalSession) {
    return {
      running: false,
      busy: false,
      cwd: '',
      shell: getSystemShell().label,
      output: '',
      history: [],
      lastExitCode: null,
      envCount: 0,
    }
  }

  return {
    running: terminalSession.running,
    busy: terminalSession.busy,
    cwd: terminalSession.cwd,
    shell: terminalSession.shell,
    output: terminalSession.output,
    history: terminalSession.history,
    lastExitCode: terminalSession.lastExitCode,
    envCount: Object.keys(terminalSession.env).length,
  }
}

function emitTerminalState() {
  sendTerminalEvent('terminal:state', getTerminalSnapshot())
}

function ensureInsideRoot(root, targetPath) {
  const resolved = path.resolve(targetPath)
  const relative = path.relative(root, resolved)

  if (relative.startsWith('..') || path.isAbsolute(relative)) {
    throw new Error('Le terminal ne peut pas sortir du dossier de travail.')
  }

  return resolved
}

async function ensureTerminalSession(forceRestart = false) {
  if (terminalSession && terminalSession.running && !forceRestart) {
    return getTerminalSnapshot()
  }

  if (terminalSession?.activeProcess) {
    terminalSession.activeProcess.kill('SIGTERM')
  }

  const root = await getWorkspaceRoot()
  terminalSession = {
    ...getEmptyTerminalState(),
    running: true,
    cwd: root,
  }

  appendTerminalOutput(
    `[DAGRON] Session terminal initialisée dans ${root}\n[DAGRON] Shell configuré : ${terminalSession.shell}\n`,
  )
  emitTerminalState()
  return getTerminalSnapshot()
}

async function clearTerminalSessionOutput() {
  await ensureTerminalSession()

  if (!terminalSession) {
    return getTerminalSnapshot()
  }

  terminalSession.output = ''
  emitTerminalState()
  return getTerminalSnapshot()
}

async function restartTerminalSession() {
  await ensureTerminalSession(true)
  return getTerminalSnapshot()
}

async function interruptTerminalProcess() {
  if (!terminalSession?.activeProcess) {
    return getTerminalSnapshot()
  }

  terminalSession.activeProcess.kill('SIGTERM')
  appendTerminalOutput('[DAGRON] Interruption demandée.\n')
  return getTerminalSnapshot()
}

async function handleBuiltinTerminalCommand(command) {
  if (!terminalSession) {
    return false
  }

  const trimmed = command.trim()

  if (trimmed === 'clear') {
    terminalSession.output = ''
    emitTerminalState()
    return true
  }

  if (trimmed === 'pwd') {
    appendTerminalOutput(`${terminalSession.cwd}\n`)
    terminalSession.lastExitCode = 0
    emitTerminalState()
    return true
  }

  if (trimmed.startsWith('cd')) {
    const [, rawTarget] = trimmed.split(/\s+/, 2)
    const target = rawTarget?.trim() || '.'
    const nextPath = ensureInsideRoot(
      await getWorkspaceRoot(),
      path.resolve(terminalSession.cwd, target),
    )

    if (!(await pathExists(nextPath))) {
      throw new Error(`Répertoire introuvable : ${target}`)
    }

    terminalSession.cwd = nextPath
    appendTerminalOutput(`[DAGRON] Répertoire courant : ${terminalSession.cwd}\n`)
    terminalSession.lastExitCode = 0
    emitTerminalState()
    return true
  }

  if (trimmed.startsWith('export ')) {
    const definition = trimmed.slice(7).trim()
    const [key, ...rest] = definition.split('=')

    if (!key || rest.length === 0) {
      throw new Error('Syntaxe attendue : export CLE=valeur')
    }

    terminalSession.env[key.trim()] = rest.join('=').trim()
    appendTerminalOutput(`[DAGRON] Variable enregistrée : ${key.trim()}\n`)
    terminalSession.lastExitCode = 0
    emitTerminalState()
    return true
  }

  if (trimmed.startsWith('unset ')) {
    const key = trimmed.slice(6).trim()
    delete terminalSession.env[key]
    appendTerminalOutput(`[DAGRON] Variable supprimée : ${key}\n`)
    terminalSession.lastExitCode = 0
    emitTerminalState()
    return true
  }

  return false
}

async function runTerminalCommand(command) {
  await ensureTerminalSession()

  if (!terminalSession) {
    throw new Error('Session terminal indisponible.')
  }

  const trimmed = command.trim()

  if (!trimmed) {
    throw new Error('Commande vide.')
  }

  if (terminalSession.busy) {
    throw new Error('Le terminal exécute déjà une commande.')
  }

  terminalSession.history = [...terminalSession.history.slice(-49), trimmed]
  appendTerminalOutput(`\n${terminalSession.cwd} $ ${trimmed}\n`)

  if (await handleBuiltinTerminalCommand(trimmed)) {
    return getTerminalSnapshot()
  }

  const shell = getSystemShell()
  terminalSession.busy = true
  terminalSession.shell = shell.label
  emitTerminalState()

  return await new Promise((resolve, reject) => {
    const child = spawn(shell.command, shell.buildArgs(trimmed), {
      cwd: terminalSession.cwd,
      env: {
        ...process.env,
        ...terminalSession.env,
      },
      stdio: ['ignore', 'pipe', 'pipe'],
    })

    terminalSession.activeProcess = child

    child.stdout.on('data', (data) => {
      appendTerminalOutput(data.toString('utf8'))
    })

    child.stderr.on('data', (data) => {
      appendTerminalOutput(data.toString('utf8'))
    })

    child.on('error', (error) => {
      terminalSession.busy = false
      terminalSession.activeProcess = null
      terminalSession.lastExitCode = 1
      appendTerminalOutput(`[DAGRON] Erreur terminal : ${error.message}\n`)
      emitTerminalState()
      reject(error)
    })

    child.on('close', (code, signal) => {
      terminalSession.busy = false
      terminalSession.activeProcess = null
      terminalSession.lastExitCode = code ?? (signal ? 130 : 0)

      if (signal) {
        appendTerminalOutput(`[DAGRON] Processus interrompu par ${signal}\n`)
      } else {
        appendTerminalOutput(`[DAGRON] Fin de commande, code ${terminalSession.lastExitCode}\n`)
      }

      emitTerminalState()
      resolve(getTerminalSnapshot())
    })
  })
}

function getLanguageFromPath(filePath) {
  const extension = path.extname(filePath).toLowerCase()
  const map = {
    '.ts': 'typescript',
    '.tsx': 'typescript',
    '.js': 'javascript',
    '.jsx': 'javascript',
    '.json': 'json',
    '.md': 'markdown',
    '.css': 'css',
    '.html': 'html',
    '.mjs': 'javascript',
  }

  return map[extension] || 'plaintext'
}

function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1600,
    height: 980,
    minWidth: 1180,
    minHeight: 760,
    backgroundColor: '#0b1220',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.mjs'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  })

  if (isDev) {
    mainWindow.loadURL(DEV_SERVER_URL)
  } else {
    mainWindow.loadFile(path.join(__dirname, '../dist/index.html'))
  }
}

ipcMain.handle('app:get-shell-data', async () => {
  const [workspace, git, agents, auth] = await Promise.all([
    listDirectory('.'),
    getGitStatus(),
    getLocalAgents(),
    readSettings(),
  ])

  return {
    workspace,
    git,
    agents,
    auth: {
      hasPassword: Boolean(auth.passwordHash),
      defaultPasswordHint: DEFAULT_PASSWORD,
    },
  }
})

ipcMain.handle('auth:status', async () => {
  const settings = await readSettings()
  return { hasPassword: Boolean(settings.passwordHash) }
})

ipcMain.handle('auth:setup', async (_event, password) => {
  if (!password || password.length < 4) {
    throw new Error('Le mot de passe doit contenir au moins 4 caractères.')
  }

  await writeSettings({ passwordHash: sha256(password) })
  return { success: true }
})

ipcMain.handle('auth:unlock', async (_event, password) => {
  const settings = await readSettings()
  return { success: settings.passwordHash === sha256(password) }
})

ipcMain.handle('workspace:list', async (_event, relativePath) => listDirectory(relativePath))
ipcMain.handle('workspace:readFile', async (_event, relativePath) => readTextFile(relativePath))
ipcMain.handle('workspace:saveFile', async (_event, relativePath, content) =>
  saveTextFile(relativePath, content),
)
ipcMain.handle('workspace:runCommand', async (_event, command) => runShellCommand(command))
ipcMain.handle('workspace:gitStatus', async () => getGitStatus())
ipcMain.handle('workspace:agents', async () => getLocalAgents())
ipcMain.handle('workspace:catalog', async () => getEnhancedCatalog())
ipcMain.handle('workspace:toggleExtension', async (_event, extensionId) =>
  toggleExtension(extensionId),
)
ipcMain.handle('workspace:getLanguage', async (_event, relativePath) =>
  getLanguageFromPath(relativePath),
)
ipcMain.handle('terminal:ensure', async () => ensureTerminalSession())
ipcMain.handle('terminal:run', async (_event, command) => runTerminalCommand(command))
ipcMain.handle('terminal:interrupt', async () => interruptTerminalProcess())
ipcMain.handle('terminal:clear', async () => clearTerminalSessionOutput())
ipcMain.handle('terminal:restart', async () => restartTerminalSession())

app.whenReady().then(() => {
  createMainWindow()

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createMainWindow()
    }
  })
})

app.on('window-all-closed', () => {
  if (terminalSession?.activeProcess) {
    terminalSession.activeProcess.kill('SIGTERM')
  }

  if (process.platform !== 'darwin') {
    app.quit()
  }
})
