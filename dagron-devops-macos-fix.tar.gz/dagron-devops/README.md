# DAGRON DevOps

Socle initial d’un éditeur de code `desktop-first` inspiré d’un IDE moderne, orienté `DevOps`, développement logiciel et IA locale.

## Fonctions déjà livrées

- écran de verrouillage avec mot de passe local
- explorateur de fichiers local
- ouverture et sauvegarde de fichiers texte
- éditeur `Monaco`
- détection Git locale
- terminal intégré avec historique, `cd`, `pwd`, `clear`, `export`, `unset`
- runner de commandes ponctuelles
- panneau `Amélioré` pour agents et modules
- détection d’`Ollama`
- barre d’état inspirée d’un IDE

## Lancer le projet

```bash
npm install
npm run dev
```

Le mode développement démarre `Vite` et `Electron` ensemble.

## Mot de passe initial

Le mot de passe de démonstration par défaut est :

```text
dagron
```

Vous pouvez ensuite le remplacer lors de l’évolution du module d’administration.

## Structure

- `electron/` : fenêtre desktop et API locales
- `src/` : interface React
- `docs/architecture-mvp.md` : architecture et découpage MVP

## Étapes suivantes

1. brancher le chat IA local contextualisé
2. implémenter une recherche globale projet
3. rendre le catalogue d’extensions réellement installable
4. enrichir Git et les onglets multi-fichiers
