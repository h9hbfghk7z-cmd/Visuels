import {
  useEffect,
  useMemo,
  useRef,
  useState,
  type FormEvent,
} from 'react'
import Editor from '@monaco-editor/react'
import { FitAddon } from '@xterm/addon-fit'
import { Terminal } from '@xterm/xterm'
import '@xterm/xterm/css/xterm.css'
import './App.css'

function App() {
  const [loading, setLoading] = useState(true)
  const [isUnlocked, setIsUnlocked] = useState(false)
  const [authMode, setAuthMode] = useState<'setup' | 'unlock'>('unlock')
  const [password, setPassword] = useState('')
  const [authError, setAuthError] = useState('')
  const [workspace, setWorkspace] = useState<WorkspaceResponse | null>(null)
  const [workspaceRoot, setWorkspaceRoot] = useState('')
  const [currentPath, setCurrentPath] = useState('.')
  const [openFilePath, setOpenFilePath] = useState('')
  const [editorValue, setEditorValue] = useState('')
  const [language, setLanguage] = useState('plaintext')
  const [git, setGit] = useState({ branch: 'chargement', dirty: false })
  const [agents, setAgents] = useState<{ runtime: string; models: string[] }>({
    runtime: 'chargement',
    models: [],
  })
  const [catalog, setCatalog] = useState<CatalogItem[]>([])
  const [saveStatus, setSaveStatus] = useState('Aucune modification enregistrée.')
  const [terminalInput, setTerminalInput] = useState('npm run lint')
  const [terminalState, setTerminalState] = useState<TerminalState>({
    running: false,
    busy: false,
    cwd: '',
    shell: 'shell',
    output: '',
    history: [],
    lastExitCode: null,
    envCount: 0,
  })
  const [terminalHint, setTerminalHint] = useState(
    'Commandes intégrées : `cd`, `pwd`, `clear`, `export`, `unset`.',
  )
  const terminalContainerRef = useRef<HTMLDivElement | null>(null)
  const terminalRef = useRef<Terminal | null>(null)
  const fitAddonRef = useRef<FitAddon | null>(null)

  const breadcrumb = useMemo(() => {
    if (!currentPath || currentPath === '.') return ['Racine']
    return ['Racine', ...currentPath.split('/')]
  }, [currentPath])

  const activeModel = agents.models[0] || 'aucun'

  async function refreshShellData() {
    const shellData = await window.dagronApi.getShellData()
    setWorkspace(shellData.workspace)
    setWorkspaceRoot(shellData.workspace.root)
    setCurrentPath(shellData.workspace.currentPath)
    setGit(shellData.git)
    setAgents(shellData.agents)
    setCatalog(await window.dagronApi.getCatalog())
    setAuthMode(shellData.auth.hasPassword ? 'unlock' : 'setup')
    setLoading(false)
  }

  useEffect(() => {
    refreshShellData().catch((error: Error) => {
      setAuthError(error.message)
      setLoading(false)
    })
  }, [])

  useEffect(() => {
    if (!isUnlocked || !terminalContainerRef.current || terminalRef.current) {
      return
    }

    const terminal = new Terminal({
      convertEol: true,
      disableStdin: true,
      cursorBlink: true,
      fontSize: 13,
      fontFamily:
        "'SFMono-Regular', SFMono-Regular, ui-monospace, Menlo, Consolas, monospace",
      theme: {
        background: '#020617',
        foreground: '#cbd5e1',
        cursor: '#60a5fa',
        selectionBackground: '#1d4ed8',
      },
    })

    const fitAddon = new FitAddon()
    terminal.loadAddon(fitAddon)
    terminal.open(terminalContainerRef.current)
    fitAddon.fit()
    terminalRef.current = terminal
    fitAddonRef.current = fitAddon

    const handleResize = () => fitAddon.fit()
    window.addEventListener('resize', handleResize)

    return () => {
      window.removeEventListener('resize', handleResize)
      fitAddonRef.current = null
      terminalRef.current?.dispose()
      terminalRef.current = null
    }
  }, [isUnlocked])

  useEffect(() => {
    if (!isUnlocked) return

    const unsubscribeData = window.dagronApi.onTerminalData(({ chunk }) => {
      terminalRef.current?.write(chunk)
    })

    const unsubscribeState = window.dagronApi.onTerminalState((nextState) => {
      setTerminalState(nextState)
      if (terminalRef.current) {
        terminalRef.current.clear()
        terminalRef.current.write(nextState.output)
        fitAddonRef.current?.fit()
      }
    })

    window.dagronApi
      .ensureTerminal()
      .then((state) => {
        setTerminalState(state)
        terminalRef.current?.clear()
        terminalRef.current?.write(state.output)
        fitAddonRef.current?.fit()
      })
      .catch((error: Error) => {
        setTerminalHint(error.message)
      })

    return () => {
      unsubscribeData()
      unsubscribeState()
    }
  }, [isUnlocked])

  async function openDirectory(pathToOpen: string) {
    const nextWorkspace = await window.dagronApi.listWorkspace(pathToOpen)
    setWorkspace(nextWorkspace)
    setCurrentPath(nextWorkspace.currentPath)
  }

  async function openFile(pathToOpen: string) {
    const [file, fileLanguage] = await Promise.all([
      window.dagronApi.readFile(pathToOpen),
      window.dagronApi.getLanguage(pathToOpen),
    ])

    setOpenFilePath(file.path)
    setEditorValue(file.content)
    setLanguage(fileLanguage)
    setSaveStatus(`Fichier ouvert : ${file.path}`)
  }

  async function handleAuthSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setAuthError('')

    try {
      if (authMode === 'setup') {
        await window.dagronApi.setupPassword(password)
        setIsUnlocked(true)
        setPassword('')
        return
      }

      const result = await window.dagronApi.unlock(password)

      if (!result.success) {
        setAuthError('Mot de passe invalide.')
        return
      }

      setIsUnlocked(true)
      setPassword('')
    } catch (error) {
      setAuthError(error instanceof Error ? error.message : 'Erreur d’authentification.')
    }
  }

  async function handleSave() {
    if (!openFilePath) return
    await window.dagronApi.saveFile(openFilePath, editorValue)
    setSaveStatus(`Enregistré : ${openFilePath}`)
    setGit(await window.dagronApi.gitStatus())
  }

  async function handleRunCommand() {
    try {
      const result = await window.dagronApi.runCommand(terminalInput)
      const output = [result.stdout, result.stderr].filter(Boolean).join('\n').trim()
      setTerminalHint(output || 'Commande ponctuelle terminée sans sortie.')
      setGit(await window.dagronApi.gitStatus())
      setAgents(await window.dagronApi.getAgents())
    } catch (error) {
      setTerminalHint(error instanceof Error ? error.message : 'Commande impossible.')
    }
  }

  async function handleToggleExtension(extensionId: string) {
    await window.dagronApi.toggleExtension(extensionId)
    setCatalog(await window.dagronApi.getCatalog())
  }

  async function handleTerminalSubmit(event?: FormEvent<HTMLFormElement>) {
    event?.preventDefault()

    try {
      setTerminalHint('Commande envoyée au terminal.')
      const nextState = await window.dagronApi.runTerminalCommand(terminalInput)
      setTerminalState(nextState)
      setGit(await window.dagronApi.gitStatus())
      setAgents(await window.dagronApi.getAgents())
      fitAddonRef.current?.fit()
    } catch (error) {
      setTerminalHint(error instanceof Error ? error.message : 'Erreur terminal.')
    }
  }

  async function handleTerminalInterrupt() {
    const nextState = await window.dagronApi.interruptTerminal()
    setTerminalState(nextState)
    setTerminalHint('Interruption envoyée au processus actif.')
  }

  async function handleTerminalClear() {
    const nextState = await window.dagronApi.clearTerminal()
    setTerminalState(nextState)
    terminalRef.current?.clear()
    setTerminalHint('Terminal effacé.')
  }

  async function handleTerminalRestart() {
    const nextState = await window.dagronApi.restartTerminal()
    setTerminalState(nextState)
    terminalRef.current?.clear()
    terminalRef.current?.write(nextState.output)
    setTerminalHint('Session terminal redémarrée.')
  }

  if (loading) {
    return <div className="boot-screen">Chargement de DAGRON DevOps…</div>
  }

  if (!isUnlocked) {
    return (
      <main className="lock-screen">
        <section className="lock-card">
          <p className="eyebrow">DAGRON DevOps</p>
          <h1>Accès local sécurisé</h1>
          <p className="lock-copy">
            {authMode === 'setup'
              ? 'Définissez le mot de passe local de l’éditeur.'
              : 'Saisissez le mot de passe pour déverrouiller l’atelier.'}
          </p>
          <form className="lock-form" onSubmit={handleAuthSubmit}>
            <label htmlFor="password">Mot de passe</label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              placeholder={authMode === 'setup' ? 'minimum 4 caractères' : 'mot de passe'}
            />
            <button type="submit">
              {authMode === 'setup' ? 'Créer et entrer' : 'Déverrouiller'}
            </button>
          </form>
          {authError ? <p className="error-banner">{authError}</p> : null}
          {authMode === 'unlock' ? (
            <p className="hint">Mot de passe initial de démonstration : `dagron`</p>
          ) : null}
        </section>
      </main>
    )
  }

  return (
    <main className="app-shell">
      <header className="topbar">
        <div>
          <p className="eyebrow">DAGRON DevOps</p>
          <h1>Atelier local orienté DevOps et IA</h1>
        </div>
        <div className="topbar-actions">
          <button type="button" onClick={() => openDirectory(currentPath)}>
            Actualiser
          </button>
          <button type="button" onClick={handleSave} disabled={!openFilePath}>
            Enregistrer
          </button>
          <button type="button" onClick={() => setIsUnlocked(false)}>
            Log Out
          </button>
        </div>
      </header>

      <section className="workspace-layout">
        <aside className="left-sidebar">
          <section className="panel-block">
            <div className="panel-header">
              <h2>Explorateur</h2>
              <span>{breadcrumb.join(' / ')}</span>
            </div>
            {currentPath !== '.' ? (
              <button
                type="button"
                className="ghost-row"
                onClick={() => {
                  const parent = currentPath.split('/').slice(0, -1).join('/') || '.'
                  openDirectory(parent)
                }}
              >
                ← remonter
              </button>
            ) : null}
            <div className="tree-list">
              {workspace?.items.map((item) => (
                <button
                  key={item.path}
                  type="button"
                  className={`tree-item ${openFilePath === item.path ? 'active' : ''}`}
                  onClick={() =>
                    item.type === 'directory' ? openDirectory(item.path) : openFile(item.path)
                  }
                >
                  <span>{item.type === 'directory' ? '📁' : '📄'}</span>
                  <span>{item.name}</span>
                </button>
              ))}
            </div>
          </section>

          <section className="panel-block">
            <div className="panel-header">
              <h2>Amélioré</h2>
              <span>Agents et modules locaux</span>
            </div>
            <div className="catalog-list">
              {catalog.map((item) => (
                <article key={item.id} className="catalog-card">
                  <div>
                    <strong>{item.name}</strong>
                    <p>{item.description}</p>
                    <small>
                      {item.category} · {item.installed ? 'installé' : 'non détecté'}
                    </small>
                  </div>
                  <button type="button" onClick={() => handleToggleExtension(item.id)}>
                    {item.active ? 'Désactiver' : 'Activer'}
                  </button>
                </article>
              ))}
            </div>
          </section>

          <section className="panel-block">
            <div className="panel-header">
              <h2>Paramètres</h2>
              <span>Essentiel uniquement</span>
            </div>
            <ul className="settings-list">
              <li>`Appearance` : thème sombre actif</li>
              <li>`Log Out` : verrouiller la session</li>
              <li>`Archive` : à brancher sur l’historique local</li>
              <li>`Unread` : à brancher sur le centre d’alertes</li>
              <li>`Source` : à brancher sur le catalogue configuré</li>
            </ul>
          </section>
        </aside>

        <section className="center-stage">
          <div className="editor-toolbar">
            <div className="tab-strip">
              <button type="button" className="tab active">
                {openFilePath || 'Aucun fichier ouvert'}
              </button>
            </div>
            <span>{saveStatus}</span>
          </div>

          <div className="editor-frame">
            <Editor
              height="100%"
              defaultLanguage="typescript"
              language={language}
              value={editorValue}
              onChange={(value) => setEditorValue(value ?? '')}
              theme="vs-dark"
              options={{
                fontSize: 14,
                minimap: { enabled: false },
                smoothScrolling: true,
                automaticLayout: true,
              }}
            />
          </div>

          <div className="runner-panel">
            <div className="panel-header">
              <h2>Terminal intégré</h2>
              <span>
                {terminalState.cwd || workspaceRoot || 'dossier courant'} · {terminalState.shell}
              </span>
            </div>
            <div ref={terminalContainerRef} className="terminal-surface" />
            <form className="runner-inputs" onSubmit={handleTerminalSubmit}>
              <input
                value={terminalInput}
                onChange={(event) => setTerminalInput(event.target.value)}
                placeholder="Exemple : npm run build"
              />
              <button type="submit" disabled={terminalState.busy}>
                Envoyer
              </button>
            </form>
            <div className="terminal-actions">
              <button type="button" onClick={handleTerminalInterrupt} disabled={!terminalState.busy}>
                Interrompre
              </button>
              <button type="button" onClick={handleTerminalClear}>
                Effacer
              </button>
              <button type="button" onClick={handleTerminalRestart}>
                Redémarrer
              </button>
              <button type="button" onClick={handleRunCommand}>
                Runner rapide
              </button>
            </div>
            <p className="terminal-hint">{terminalHint}</p>
          </div>
        </section>

        <aside className="right-sidebar">
          <section className="panel-block">
            <div className="panel-header">
              <h2>Contexte</h2>
              <span>Panneau droit</span>
            </div>
            <dl className="context-grid">
              <div>
                <dt>Fichier actif</dt>
                <dd>{openFilePath || 'aucun'}</dd>
              </div>
              <div>
                <dt>Runtime IA</dt>
                <dd>{agents.runtime}</dd>
              </div>
              <div>
                <dt>Modèles</dt>
                <dd>{agents.models.length ? agents.models.join(', ') : 'aucun modèle local'}</dd>
              </div>
              <div>
                <dt>Branche Git</dt>
                <dd>{git.branch}</dd>
              </div>
              <div>
                <dt>Dépôt</dt>
                <dd>{git.dirty ? 'modifié' : 'propre'}</dd>
              </div>
              <div>
                <dt>Runner</dt>
                <dd>{terminalState.busy ? 'terminal occupé' : 'terminal prêt'}</dd>
              </div>
              <div>
                <dt>Répertoire terminal</dt>
                <dd>{terminalState.cwd || workspaceRoot || 'non initialisé'}</dd>
              </div>
              <div>
                <dt>Variables de session</dt>
                <dd>{terminalState.envCount}</dd>
              </div>
              <div>
                <dt>Dernier code</dt>
                <dd>{terminalState.lastExitCode ?? 'aucun'}</dd>
              </div>
            </dl>
          </section>

          <section className="panel-block">
            <div className="panel-header">
              <h2>MVP</h2>
              <span>Priorités produit</span>
            </div>
            <ul className="settings-list">
              <li>Édition multi-fichier et sauvegarde locale</li>
              <li>Détection Git et exécution de commandes</li>
              <li>Catalogue local d’agents et d’extensions</li>
              <li>Terminal intégré avec session locale</li>
            </ul>
          </section>

          <section className="panel-block">
            <div className="panel-header">
              <h2>Architecture</h2>
              <span>Socle retenu</span>
            </div>
            <ul className="settings-list">
              <li>Desktop : `Electron`</li>
              <li>Interface : `React` + `Monaco`</li>
              <li>Services locaux : `IPC` + `Node.js`</li>
              <li>IA locale : `Ollama` extensible</li>
            </ul>
          </section>
        </aside>
      </section>

      <footer className="status-bar">
        <span>Langage : {language}</span>
        <span>Encodage : UTF-8</span>
        <span>Fin de ligne : LF</span>
        <span>Branche : {git.branch}</span>
        <span>Dépôt : {git.dirty ? 'modifié' : 'propre'}</span>
        <span>Environnement : local</span>
        <span>Port : 5173</span>
        <span>Terminal : {terminalState.busy ? 'occupé' : 'prêt'}</span>
        <span>Modèle IA : {activeModel}</span>
        <span>Dossier : {workspaceRoot || 'non détecté'}</span>
      </footer>
    </main>
  )
}

export default App
