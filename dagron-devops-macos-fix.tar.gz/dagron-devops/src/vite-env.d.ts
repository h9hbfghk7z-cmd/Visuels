/// <reference types="vite/client" />

declare global {
  interface WorkspaceItem {
    name: string
    path: string
    type: 'directory' | 'file'
  }

  interface WorkspaceResponse {
    root: string
    currentPath: string
    items: WorkspaceItem[]
  }

  interface ShellData {
    workspace: WorkspaceResponse
    git: {
      branch: string
      dirty: boolean
    }
    agents: {
      runtime: string
      models: string[]
    }
    auth: {
      hasPassword: boolean
      defaultPasswordHint: string
    }
  }

  interface CatalogItem {
    id: string
    name: string
    category: string
    description: string
    active: boolean
    installed: boolean
  }

  interface DagronApi {
    getShellData: () => Promise<ShellData>
    authStatus: () => Promise<{ hasPassword: boolean }>
    setupPassword: (password: string) => Promise<{ success: boolean }>
    unlock: (password: string) => Promise<{ success: boolean }>
    listWorkspace: (relativePath?: string) => Promise<WorkspaceResponse>
    readFile: (relativePath: string) => Promise<{ path: string; content: string }>
    saveFile: (relativePath: string, content: string) => Promise<{ saved: boolean; path: string }>
    runCommand: (command: string) => Promise<{ stdout: string; stderr: string; cwd: string }>
    gitStatus: () => Promise<{ branch: string; dirty: boolean }>
    getAgents: () => Promise<{ runtime: string; models: string[] }>
    getCatalog: () => Promise<CatalogItem[]>
    toggleExtension: (extensionId: string) => Promise<boolean>
    getLanguage: (relativePath: string) => Promise<string>
    ensureTerminal: () => Promise<TerminalState>
    runTerminalCommand: (command: string) => Promise<TerminalState>
    interruptTerminal: () => Promise<TerminalState>
    clearTerminal: () => Promise<TerminalState>
    restartTerminal: () => Promise<TerminalState>
    onTerminalData: (callback: (payload: TerminalDataEvent) => void) => () => void
    onTerminalState: (callback: (payload: TerminalState) => void) => () => void
  }

  interface TerminalDataEvent {
    chunk: string
  }

  interface TerminalState {
    running: boolean
    busy: boolean
    cwd: string
    shell: string
    output: string
    history: string[]
    lastExitCode: number | null
    envCount: number
  }

  interface Window {
    dagronApi: DagronApi
  }
}

export {}
